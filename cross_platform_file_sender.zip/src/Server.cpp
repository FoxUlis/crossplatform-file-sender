#include "Server.h"
#include <iostream>
#include <cstring>

Server::Server(){
   Socket = INVALID_SOCKET_VAL;
   initWinsock();
   initSocket();
   start();
}
Server::~Server(){
    cleanup();
}

int Server::initWinsock(){
   if (init_networking() != 0){
      std::cout << "Networking initialization failed!\n";
      return 1;
   }
   return 0;
}

int Server::initSocket(){
   Socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
   if (Socket == INVALID_SOCKET_VAL){
      std::cout << "Socket creation failed!\n";
      cleanup_networking();
      return 1;
   }

   int opt = 1;
   setsockopt(Socket, SOL_SOCKET, SO_REUSEADDR, (const char*)&opt, sizeof(opt));

   serverInfo.sin_family = AF_INET;
   serverInfo.sin_addr.s_addr = INADDR_ANY;
   serverInfo.sin_port = htons(4444);

   if (bind(Socket, (struct sockaddr*)(&serverInfo), sizeof(serverInfo)) == SOCKET_ERROR_VAL){
      std::cout << "Was unable to bind socket!\n";
      cleanup();
      return 2;
   }
   return 0;
}

void Server::start(){
   FileCopier f;
   f.setIFileName();
   f.findFileSize();
   f.findNumChunks();

   if (f.getSize() == 0) {
       std::cout << "File is empty or not found. Exiting.\n";
       cleanup();
       return;
   }

   listen(Socket, 1);
   std::cout << "Waiting for incoming connections...\n";
   
   SocketType clientSocket = accept(Socket, NULL, NULL);
   if (clientSocket == INVALID_SOCKET_VAL) {
       std::cout << "Accept failed!\n";
       cleanup();
       return;
   }
   
   closesocket(Socket); 
   Socket = clientSocket;

   std::cout << "Client has connected!\n";
   sendData(f);
   cleanup();
}

void Server::cleanup(){
   if (Socket != INVALID_SOCKET_VAL) {
       shutdown(Socket, SD_SEND);
       closesocket(Socket);
       Socket = INVALID_SOCKET_VAL;
   }
   cleanup_networking();
}

void Server::sendData(FileCopier& f){
   uint32_t fileSize = f.getSize();
   uint32_t netFileSize = htonl(fileSize);
   
   std::cout << "Sending filesize... ";
   if (!sendAll(Socket, (char*)&netFileSize, sizeof(netFileSize))) {
       std::cout << "Failed.\n"; return;
   }
   std::cout << "OK\n";

   const char* extension = f.getExtension();
   uint32_t extensionLength = (uint32_t)strlen(extension);
   uint32_t netExtLen = htonl(extensionLength);

   std::cout << "Sending extension length... ";
   if (!sendAll(Socket, (char*)&netExtLen, sizeof(netExtLen))) {
       delete[] extension; return;
   }
   std::cout << "OK\n";

   std::cout << "Sending extension... ";
   if (extensionLength > 0) {
       if (!sendAll(Socket, extension, extensionLength)) {
           delete[] extension; return;
       }
   }
   std::cout << "OK\n";
   delete[] extension;

   uint32_t chunkSize = f.getChunkSize();
   char* currentChunk = new char[chunkSize];
   
   uint32_t totalBytesSent = 0;
   uint32_t bytesLeft = fileSize;

   std::cout << "Sending data...\n";

   while (bytesLeft > 0) {
       uint32_t toRead = (bytesLeft < chunkSize) ? bytesLeft : chunkSize;
       f.readChunk(currentChunk, toRead);
       
       if (!sendAll(Socket, currentChunk, toRead)) {
           std::cout << "Send error.\n";
           break;
       }
       
       totalBytesSent += toRead;
       bytesLeft -= toRead;

       std::cout << "\rSent: " << totalBytesSent / 1000000 << "/" << fileSize / 1000000 << " MB";
       std::cout.flush();
   }
   
   std::cout << "\n--->File successfully sent!\n";
   delete[] currentChunk;
}
