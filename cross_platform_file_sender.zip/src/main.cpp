#include <iostream>
#include "Server.h"
#include "Client.h"

int main() {
    std::cout << "Press 1 for client, 2 for server: ";
    int x;
    if (!(std::cin >> x)) return 1;

    if (x == 1) {
        Client c;
    }
    else {
        Server s;
    }
    
    return 0;
}
